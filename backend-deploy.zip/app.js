import './dist/main.js';

